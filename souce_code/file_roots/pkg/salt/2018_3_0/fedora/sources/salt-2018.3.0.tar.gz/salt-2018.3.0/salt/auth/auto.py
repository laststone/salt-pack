# -*- coding: utf-8 -*-
'''
An "Always Approved" eauth interface to test against, not intended for
production use
'''


def auth(username, password):  # pylint: disable=unused-argument
    '''
    Authenticate!
    '''
    return True
