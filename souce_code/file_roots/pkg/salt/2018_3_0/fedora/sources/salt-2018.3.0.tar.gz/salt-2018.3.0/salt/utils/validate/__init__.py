# -*- coding: utf-8 -*-
'''
The salt.utils.validate package contains routines for validating
components and values.
'''
