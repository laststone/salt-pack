# -*- coding: utf-8 -*-
'''
The management of salt command line utilities are stored in here
'''
