=======================
salt.modules.solarisips
=======================

.. automodule:: salt.modules.solarisips
    :members:
