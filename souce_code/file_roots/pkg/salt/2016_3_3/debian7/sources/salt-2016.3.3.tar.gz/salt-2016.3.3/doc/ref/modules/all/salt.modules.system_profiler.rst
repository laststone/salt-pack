============================
salt.modules.system_profiler
============================

.. automodule:: salt.modules.system_profiler
    :members:
