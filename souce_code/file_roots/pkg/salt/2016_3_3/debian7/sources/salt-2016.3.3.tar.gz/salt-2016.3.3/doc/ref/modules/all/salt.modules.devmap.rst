===================
salt.modules.devmap
===================

.. automodule:: salt.modules.devmap
    :members:
