salt.modules.mac_assistive module
=================================

.. automodule:: salt.modules.mac_assistive
    :members:
