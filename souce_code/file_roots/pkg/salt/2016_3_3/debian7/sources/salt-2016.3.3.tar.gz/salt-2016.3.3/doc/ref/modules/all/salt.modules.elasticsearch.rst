==========================
salt.modules.elasticsearch
==========================

.. automodule:: salt.modules.elasticsearch
    :members:
