salt.modules.parallels module
=============================

.. automodule:: salt.modules.parallels
    :members:

