===========================
salt.modules.solaris_shadow
===========================

.. automodule:: salt.modules.solaris_shadow
    :members: