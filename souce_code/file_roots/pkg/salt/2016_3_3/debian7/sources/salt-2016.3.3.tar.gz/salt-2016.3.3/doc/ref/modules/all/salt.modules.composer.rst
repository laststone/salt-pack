=====================
salt.modules.composer
=====================

.. automodule:: salt.modules.composer
    :members: