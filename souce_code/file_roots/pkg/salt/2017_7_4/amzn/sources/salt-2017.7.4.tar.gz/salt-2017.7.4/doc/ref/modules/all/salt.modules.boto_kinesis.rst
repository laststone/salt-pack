salt.modules.boto_kinesis module
================================

.. automodule:: salt.modules.boto_kinesis
    :members:
    :undoc-members:
