salt.cache.consul module
========================

.. automodule:: salt.cache.consul
    :members:
