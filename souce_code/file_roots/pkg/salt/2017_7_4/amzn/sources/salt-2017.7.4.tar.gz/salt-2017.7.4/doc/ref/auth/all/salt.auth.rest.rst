==============
salt.auth.rest
==============

.. automodule:: salt.auth.rest
    :members:
