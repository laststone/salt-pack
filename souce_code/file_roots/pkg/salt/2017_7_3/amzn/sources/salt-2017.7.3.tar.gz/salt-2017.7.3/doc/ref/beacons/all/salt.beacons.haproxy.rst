salt.beacons.haproxy module
===========================

.. automodule:: salt.beacons.haproxy
    :members:
    :undoc-members:
