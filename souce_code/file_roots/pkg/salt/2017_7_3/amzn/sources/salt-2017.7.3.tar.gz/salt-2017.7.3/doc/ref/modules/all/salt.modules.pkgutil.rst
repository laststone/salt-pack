====================
salt.modules.pkgutil
====================

.. automodule:: salt.modules.pkgutil
    :members:
    :exclude-members: available_version