salt.engines.hipchat module
===========================

.. automodule:: salt.engines.hipchat
    :members:
    :undoc-members:
