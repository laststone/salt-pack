====================
salt.modules.osquery
====================

.. automodule:: salt.modules.osquery
    :members: