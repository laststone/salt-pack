=====================
salt.modules.boto_elb
=====================

.. automodule:: salt.modules.boto_elb
    :members: