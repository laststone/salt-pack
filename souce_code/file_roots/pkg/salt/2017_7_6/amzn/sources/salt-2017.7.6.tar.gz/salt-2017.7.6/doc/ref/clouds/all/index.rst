.. _all-salt.clouds:

=============
cloud modules
=============

.. currentmodule:: salt.cloud.clouds

.. autosummary::
    :toctree:
    :template: autosummary.rst.tmpl

    aliyun
    azurearm
    cloudstack
    digital_ocean
    dimensiondata
    ec2
    gce
    gogrid
    joyent
    linode
    lxc
    msazure
    nova
    opennebula
    openstack
    parallels
    profitbricks
    proxmox
    pyrax
    qingcloud
    saltify
    scaleway
    softlayer
    softlayer_hw
    virtualbox
    vmware
    vultrpy
