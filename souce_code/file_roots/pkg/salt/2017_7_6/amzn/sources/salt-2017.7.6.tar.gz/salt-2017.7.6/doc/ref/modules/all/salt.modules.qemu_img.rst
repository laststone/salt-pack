=====================
salt.modules.qemu_img
=====================

.. automodule:: salt.modules.qemu_img
    :members: