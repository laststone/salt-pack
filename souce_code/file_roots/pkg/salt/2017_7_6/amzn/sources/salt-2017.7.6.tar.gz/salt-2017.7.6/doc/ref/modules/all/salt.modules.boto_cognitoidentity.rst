salt.modules.boto_cognitoidentity module
========================================

.. automodule:: salt.modules.boto_cognitoidentity
    :members:
