===============================
salt.log.handlers.log4mongo_mod
===============================

.. automodule:: salt.log.handlers.log4mongo_mod
