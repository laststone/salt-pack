===================
salt.modules.puppet
===================

.. automodule:: salt.modules.puppet
    :members: