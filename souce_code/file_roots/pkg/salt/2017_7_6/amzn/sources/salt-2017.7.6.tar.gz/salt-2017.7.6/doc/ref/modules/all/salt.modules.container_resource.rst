===============================
salt.modules.container_resource
===============================

.. automodule:: salt.modules.container_resource
    :members: