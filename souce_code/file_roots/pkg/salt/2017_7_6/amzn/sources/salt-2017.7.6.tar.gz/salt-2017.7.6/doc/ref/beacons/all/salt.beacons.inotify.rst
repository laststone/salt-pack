====================
salt.beacons.inotify
====================

.. automodule:: salt.beacons.inotify
    :members: