salt.modules.mattermost module
==============================

.. automodule:: salt.modules.mattermost
    :members:
    :undoc-members:
