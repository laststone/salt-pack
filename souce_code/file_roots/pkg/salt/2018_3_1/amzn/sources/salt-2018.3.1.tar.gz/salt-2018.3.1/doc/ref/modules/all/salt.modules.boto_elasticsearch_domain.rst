salt.modules.boto_elasticsearch_domain module
=============================================

.. automodule:: salt.modules.boto_elasticsearch_domain
    :members:
