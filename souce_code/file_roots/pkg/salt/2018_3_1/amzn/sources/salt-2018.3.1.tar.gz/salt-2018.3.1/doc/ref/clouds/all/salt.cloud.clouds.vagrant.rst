=========================
salt.cloud.clouds.vagrant
=========================

.. automodule:: salt.cloud.clouds.vagrant
    :members:
