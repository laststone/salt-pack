=======================
salt.modules.mod_random
=======================

.. automodule:: salt.modules.mod_random
    :members: