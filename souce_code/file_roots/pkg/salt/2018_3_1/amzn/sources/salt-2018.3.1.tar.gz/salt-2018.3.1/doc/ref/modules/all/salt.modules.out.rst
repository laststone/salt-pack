salt.modules.out module
=======================

.. automodule:: salt.modules.out
    :members:
