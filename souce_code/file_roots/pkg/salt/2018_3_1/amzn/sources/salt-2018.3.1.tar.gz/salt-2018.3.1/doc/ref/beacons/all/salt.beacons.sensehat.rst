salt.beacons.sensehat module
=======================

.. automodule:: salt.beacons.sensehat
    :members:
