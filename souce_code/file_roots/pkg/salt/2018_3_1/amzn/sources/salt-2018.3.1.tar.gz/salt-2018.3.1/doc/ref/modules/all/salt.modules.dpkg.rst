=================
salt.modules.dpkg
=================

.. automodule:: salt.modules.dpkg
    :members: