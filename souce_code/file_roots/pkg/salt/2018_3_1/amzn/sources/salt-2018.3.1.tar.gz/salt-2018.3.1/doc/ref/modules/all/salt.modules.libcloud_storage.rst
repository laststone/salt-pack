salt.modules.libcloud_storage module
================================

.. automodule:: salt.modules.libcloud_storage
    :members:
    :undoc-members:
