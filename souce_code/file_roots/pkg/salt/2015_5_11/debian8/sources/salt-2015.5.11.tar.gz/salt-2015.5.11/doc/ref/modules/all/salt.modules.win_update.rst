=======================
salt.modules.win_update
=======================

.. automodule:: salt.modules.win_update
    :members: