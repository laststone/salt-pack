=============================
salt.returners.hipchat_return
=============================

.. automodule:: salt.returners.hipchat_return
    :members:
