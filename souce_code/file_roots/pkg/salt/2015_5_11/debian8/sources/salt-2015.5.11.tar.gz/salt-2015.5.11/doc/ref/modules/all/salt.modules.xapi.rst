=================
salt.modules.xapi
=================

.. automodule:: salt.modules.xapi
    :members: