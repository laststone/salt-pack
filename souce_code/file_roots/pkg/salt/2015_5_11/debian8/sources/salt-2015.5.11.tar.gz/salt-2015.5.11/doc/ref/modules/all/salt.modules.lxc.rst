================
salt.modules.lxc
================

.. automodule:: salt.modules.lxc
    :members:
    :exclude-members: set_pass
