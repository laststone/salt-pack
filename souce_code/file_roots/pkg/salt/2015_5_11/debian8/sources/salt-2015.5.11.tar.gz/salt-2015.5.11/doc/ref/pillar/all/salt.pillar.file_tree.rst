=====================
salt.pillar.file_tree
=====================

.. automodule:: salt.pillar.file_tree
    :members: