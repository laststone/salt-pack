===========================
salt.pillar.varstack_pillar
===========================

.. automodule:: salt.pillar.varstack_pillar
    :members: