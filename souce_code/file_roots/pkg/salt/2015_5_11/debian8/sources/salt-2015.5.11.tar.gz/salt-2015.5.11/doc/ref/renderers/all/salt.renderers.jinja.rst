====================
salt.renderers.jinja
====================

.. currentmodule:: salt.renderers.jinja

.. automodule:: salt.renderers.jinja
    :members:

.. autoclass:: salt.utils.jinja.SerializerExtension