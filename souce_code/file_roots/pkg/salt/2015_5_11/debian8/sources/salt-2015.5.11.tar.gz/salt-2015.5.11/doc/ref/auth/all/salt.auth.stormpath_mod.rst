=======================
salt.auth.stormpath_mod
=======================

.. automodule:: salt.auth.stormpath_mod
    :members: