:orphan:

=================
Python client API
=================

.. seealso:: Moved to :ref:`client-apis`