========================
salt.modules.supervisord
========================

.. automodule:: salt.modules.supervisord
    :members: