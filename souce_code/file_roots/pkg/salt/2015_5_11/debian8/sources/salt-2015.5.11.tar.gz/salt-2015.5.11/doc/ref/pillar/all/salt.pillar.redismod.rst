====================
salt.pillar.redismod
====================

.. automodule:: salt.pillar.redismod
    :members: