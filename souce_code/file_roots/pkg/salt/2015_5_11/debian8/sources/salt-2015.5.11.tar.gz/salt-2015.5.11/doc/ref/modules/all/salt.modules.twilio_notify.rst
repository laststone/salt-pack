==========================
salt.modules.twilio_notify
==========================

.. automodule:: salt.modules.twilio_notify
    :members: