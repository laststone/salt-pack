=====================
salt.modules.win_disk
=====================

.. automodule:: salt.modules.win_disk
    :members: