===========================
salt.returners.kafka_return
===========================

.. automodule:: salt.returners.kafka_return
    :members: