===================
salt.pillar.libvirt
===================

.. automodule:: salt.pillar.libvirt
    :members: