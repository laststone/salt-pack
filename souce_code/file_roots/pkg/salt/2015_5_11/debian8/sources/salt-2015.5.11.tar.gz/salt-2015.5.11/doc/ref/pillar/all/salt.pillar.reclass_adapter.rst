===========================
salt.pillar.reclass_adapter
===========================

.. automodule:: salt.pillar.reclass_adapter
    :members: