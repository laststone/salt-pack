==========================
salt.returners.etcd_return
==========================

.. automodule:: salt.returners.etcd_return
    :members: