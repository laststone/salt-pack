======================
salt.renderers.msgpack
======================

.. automodule:: salt.renderers.msgpack
    :members: