==================================
salt.returners.mongo_future_return
==================================

.. automodule:: salt.returners.mongo_future_return
    :members: