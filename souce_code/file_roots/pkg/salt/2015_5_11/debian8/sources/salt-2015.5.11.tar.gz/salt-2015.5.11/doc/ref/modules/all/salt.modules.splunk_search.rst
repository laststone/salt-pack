==========================
salt.modules.splunk_search
==========================

.. automodule:: salt.modules.splunk_search
    :members: