============================
salt.returners.django_return
============================

.. automodule:: salt.returners.django_return
    :members: