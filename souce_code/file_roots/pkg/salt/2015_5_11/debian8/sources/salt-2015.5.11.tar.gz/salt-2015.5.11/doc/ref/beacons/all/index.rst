.. _all-salt.beacons:

===================================
Full list of builtin beacon modules
===================================

.. currentmodule:: salt.beacons

.. autosummary::
    :toctree:
    :template: autosummary.rst.tmpl

    btmp
    diskusage
    inotify
    journald
    load
    network_info
    service
    sh
    twilio_txt_msg
    wtmp
