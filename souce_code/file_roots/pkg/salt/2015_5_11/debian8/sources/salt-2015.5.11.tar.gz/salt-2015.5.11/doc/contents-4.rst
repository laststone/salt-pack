======================
Salt Table of Contents
======================

.. toctree::
    :maxdepth: 3
    :glob:

    ref/index
    glossary