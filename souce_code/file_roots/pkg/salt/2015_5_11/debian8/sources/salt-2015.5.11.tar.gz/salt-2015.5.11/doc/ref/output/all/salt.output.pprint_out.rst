======================
salt.output.pprint_out
======================

.. automodule:: salt.output.pprint_out
    :members: