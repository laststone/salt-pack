===================================
salt.returners.elasticsearch_return
===================================

.. automodule:: salt.returners.elasticsearch_return
    :members: