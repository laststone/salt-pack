=======================
salt.pillar.etcd_pillar
=======================

.. automodule:: salt.pillar.etcd_pillar
    :members: