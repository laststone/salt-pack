===============================
salt.returners.couchbase_return
===============================

.. automodule:: salt.returners.couchbase_return
    :members: