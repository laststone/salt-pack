====================
salt.modules.varnish
====================

.. automodule:: salt.modules.varnish
    :members: