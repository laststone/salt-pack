==================
salt.modules.omapi
==================

.. automodule:: salt.modules.omapi
    :members: