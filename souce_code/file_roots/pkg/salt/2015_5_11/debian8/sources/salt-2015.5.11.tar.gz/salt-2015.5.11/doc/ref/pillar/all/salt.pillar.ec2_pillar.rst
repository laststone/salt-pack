======================
salt.pillar.ec2_pillar
======================

.. automodule:: salt.pillar.ec2_pillar
    :members: