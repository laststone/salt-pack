=======================
salt.modules.vbox_guest
=======================

.. automodule:: salt.modules.vbox_guest
    :members: