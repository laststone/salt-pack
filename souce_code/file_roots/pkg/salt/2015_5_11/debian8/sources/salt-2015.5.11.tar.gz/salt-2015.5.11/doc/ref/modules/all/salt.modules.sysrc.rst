==================
salt.modules.sysrc
==================

.. automodule:: salt.modules.sysrc
    :members: