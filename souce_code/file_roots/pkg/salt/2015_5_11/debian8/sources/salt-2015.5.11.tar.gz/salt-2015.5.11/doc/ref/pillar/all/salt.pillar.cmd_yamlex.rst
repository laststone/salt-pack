======================
salt.pillar.cmd_yamlex
======================

.. automodule:: salt.pillar.cmd_yamlex
    :members: