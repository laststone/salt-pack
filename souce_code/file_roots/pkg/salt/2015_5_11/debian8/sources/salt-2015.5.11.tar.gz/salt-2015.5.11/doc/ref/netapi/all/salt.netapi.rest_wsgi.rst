=========
rest_wsgi
=========

.. automodule:: salt.netapi.rest_wsgi

.. py:currentmodule:: salt.netapi.rest_wsgi