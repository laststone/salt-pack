==============================
salt.returners.memcache_return
==============================

.. automodule:: salt.returners.memcache_return
    :members: