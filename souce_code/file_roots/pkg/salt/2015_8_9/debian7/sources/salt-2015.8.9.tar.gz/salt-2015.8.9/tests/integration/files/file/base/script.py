#!/usr/bin/env python

import sys

print(' '.join(sys.argv[1:]))
