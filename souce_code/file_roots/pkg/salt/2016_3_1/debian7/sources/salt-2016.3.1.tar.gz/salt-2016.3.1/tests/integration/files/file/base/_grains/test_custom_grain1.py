#!/usr/bin/env python
def myfunction():
     grains = {}
     grains['a_custom'] = {'k1': 'v1'}
     return grains
