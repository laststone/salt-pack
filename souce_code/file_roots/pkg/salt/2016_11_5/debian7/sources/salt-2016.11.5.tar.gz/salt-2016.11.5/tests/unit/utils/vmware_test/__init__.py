# -*- coding: utf-8 -*-
'''
Tests for functions in salt.utils.vmware
'''
