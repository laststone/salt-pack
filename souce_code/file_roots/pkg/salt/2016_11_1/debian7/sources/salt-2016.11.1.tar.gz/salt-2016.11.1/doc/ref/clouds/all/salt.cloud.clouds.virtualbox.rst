========================
salt.cloud.clouds.virtualbox
========================

.. automodule:: salt.cloud.clouds.virtualbox
    :members:
    :exclude-members: get_configured_provider
