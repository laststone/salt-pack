======================
salt.modules.logrotate
======================

.. automodule:: salt.modules.logrotate
    :members: