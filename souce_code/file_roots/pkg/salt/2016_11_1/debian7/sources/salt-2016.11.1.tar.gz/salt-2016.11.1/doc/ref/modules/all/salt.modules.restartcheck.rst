salt.modules.restartcheck module
================================

.. automodule:: salt.modules.restartcheck
    :members:
