=========================
salt.modules.slack_notify
=========================

.. automodule:: salt.modules.slack_notify
    :members:
