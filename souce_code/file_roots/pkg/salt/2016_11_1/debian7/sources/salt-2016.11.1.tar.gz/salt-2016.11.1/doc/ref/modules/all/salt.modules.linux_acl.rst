======================
salt.modules.linux_acl
======================

.. automodule:: salt.modules.linux_acl
    :members: