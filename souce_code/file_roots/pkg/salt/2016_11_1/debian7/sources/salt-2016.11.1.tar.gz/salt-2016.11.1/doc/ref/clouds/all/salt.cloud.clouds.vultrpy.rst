salt.cloud.clouds.vultrpy module
================================

.. automodule:: salt.cloud.clouds.vultrpy
    :members:
