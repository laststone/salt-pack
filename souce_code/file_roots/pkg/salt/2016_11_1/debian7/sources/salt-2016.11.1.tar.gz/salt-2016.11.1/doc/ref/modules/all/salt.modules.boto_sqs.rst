=====================
salt.modules.boto_sqs
=====================

.. automodule:: salt.modules.boto_sqs
    :members: