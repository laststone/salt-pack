Alabaster sphinx theme from https://github.com/bitprophet/alabaster
