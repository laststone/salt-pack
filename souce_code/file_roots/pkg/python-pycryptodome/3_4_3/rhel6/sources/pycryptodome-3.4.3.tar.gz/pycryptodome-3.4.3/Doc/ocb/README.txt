These are the free licenses granted by Prof. Phillip Rogaway
to users of products that implement OCB.

They have been downloaded on May, 27 2015 from the URL:
http://web.cs.ucdavis.edu/~rogaway/ocb/license.htm
